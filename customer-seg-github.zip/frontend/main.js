document.getElementById('uploadBtn').onclick = async () => {
  const fileInput = document.getElementById('csvFile');
  const backend = document.getElementById('backendUrl').value.trim();
  if (!fileInput.files.length) return alert('Upload a CSV file.');
  if (!backend) return alert('Enter backend URL.');
  const file = fileInput.files[0];
  const form = new FormData();
  form.append('file', file);

  document.getElementById('status').innerText = 'Uploading and processing...';
  try {
    const res = await fetch(backend, { method: 'POST', body: form });
    if (!res.ok) {
      const text = await res.text();
      throw new Error(text || 'Server error');
    }
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'clustered_customers.csv';
    a.innerText = 'Download clustered CSV';
    const d = document.getElementById('download');
    d.innerHTML = '';
    d.appendChild(a);
    document.getElementById('status').innerText = 'Done.';
  } catch (err) {
    document.getElementById('status').innerText = 'Error: ' + err.message;
  }
};

document.getElementById('predictBtn').onclick = async () => {
  const backend = document.getElementById('backendUrl').value.trim();
  if (!backend) return alert('Enter backend URL.');
  const jsonText = document.getElementById('singleJson').value;
  let payload;
  try {
    payload = JSON.parse(jsonText);
  } catch {
    return alert('Invalid JSON');
  }
  try {
    const url = backend.replace(/cluster_csv$/, 'cluster_json');
    const res = await fetch(url, {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    document.getElementById('predResult').innerText = JSON.stringify(data, null, 2);
  } catch (err) {
    document.getElementById('predResult').innerText = 'Error: ' + err.message;
  }
};
