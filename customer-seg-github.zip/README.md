# Customer Segmentation — Full Project

This repository contains a complete end-to-end Customer Segmentation project:
- Frontend: static HTML/JS/CSS (can be deployed to Firebase Hosting)
- Backend: Flask app (can be deployed to Google Cloud Run). Runs KMeans clustering on uploaded CSV.
- Dockerfile and requirements for containerized deployment.

## Structure
```
customer-seg-github/
├─ frontend/
│  ├─ index.html
│  ├─ main.js
│  └─ styles.css
├─ backend/
│  ├─ app.py
│  ├─ requirements.txt
│  └─ Dockerfile
└─ firebase.json
```

## Quick local run

### Backend
```bash
cd backend
python -m venv venv
source venv/bin/activate   # on Windows: venv\Scripts\activate
pip install -r requirements.txt
python app.py
# backend listens on http://0.0.0.0:8080 by default
```

### Frontend (local)
```bash
cd frontend
python -m http.server 8000
# open http://localhost:8000 and enter backend URL http://localhost:8080/cluster_csv
```

## Deploy
- Deploy backend to Cloud Run (Docker image) or any hosting that supports Python/Flask.
- Deploy frontend to Firebase Hosting or any static hosting.

## Files of interest
- backend/app.py: Flask backend that accepts CSV and returns clustered CSV.
- frontend/index.html + main.js: simple UI to upload CSV and get clustered output.
