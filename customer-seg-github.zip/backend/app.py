# backend/app.py
from flask import Flask, request, jsonify, send_file
import pandas as pd
import numpy as np
import io
import os
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import silhouette_score, davies_bouldin_score, calinski_harabasz_score

app = Flask(__name__)

FEATURES = ['Genre','Age','Annual Income (k$)','Spending Score (1-100)']

def normalize_df(df: pd.DataFrame):
    if 'Gender' in df.columns and 'Genre' not in df.columns:
        df = df.rename(columns={'Gender':'Genre'})
    if 'Genre' in df.columns:
        df['Genre'] = df['Genre'].map({'Male':0,'Female':1})
    missing = [f for f in FEATURES if f not in df.columns]
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    return df

def choose_k_by_silhouette(X_scaled, k_min=2, k_max=8):
    best_k = k_min
    best_score = -1
    max_k = min(k_max, X_scaled.shape[0]-1)
    for k in range(k_min, max_k+1):
        km = KMeans(n_clusters=k, random_state=42, n_init=10)
        labels = km.fit_predict(X_scaled)
        score = silhouette_score(X_scaled, labels)
        if score > best_score:
            best_score = score
            best_k = k
    return best_k, best_score

def recommend_from_row(income, spend):
    try:
        income = float(income); spend = float(spend)
    except:
        return "Use cluster profile to craft a message."
    if income >= 60 and spend >= 60:
        return "Premium customers: exclusive membership & premium bundles."
    if income >= 60 and spend < 40:
        return "High-income low-spend: retarget with personalized recommendations."
    if income < 40 and spend >= 60:
        return "Value shoppers: promote budget-friendly bundles."
    return "Low engagement: discounts & referral incentives."

@app.route("/health")
def health():
    return jsonify({"status":"ok"})

@app.route("/cluster_csv", methods=["POST"])
def cluster_csv():
    if 'file' not in request.files:
        return jsonify({"error":"No file part 'file' in request"}), 400
    file = request.files['file']
    try:
        df = pd.read_csv(file)
    except Exception as e:
        return jsonify({"error":"Could not read CSV: "+str(e)}), 400
    try:
        df = normalize_df(df)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    X = df[FEATURES].astype(float).values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    k, sil_score = choose_k_by_silhouette(X_scaled, k_min=2, k_max=8)
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(X_scaled)

    df_out = df.copy()
    df_out['Cluster'] = labels

    profile = df_out.groupby('Cluster')[FEATURES].mean().round(2)
    profile['Count'] = df_out['Cluster'].value_counts().sort_index().values
    profile_json = profile.reset_index().to_dict(orient='records')

    recs = []
    for idx, row in df_out.iterrows():
        recs.append(recommend_from_row(row['Annual Income (k$)'], row['Spending Score (1-100)']))
    df_out['Recommendation'] = recs

    csv_buffer = io.StringIO()
    df_out.to_csv(csv_buffer, index=False)
    csv_buffer.seek(0)

    return send_file(io.BytesIO(csv_buffer.getvalue().encode('utf-8')),
                     mimetype='text/csv',
                     as_attachment=True,
                     download_name='clustered_customers.csv')

@app.route("/cluster_json", methods=["POST"])
def cluster_json():
    data = request.get_json(force=True)
    if data is None:
        return jsonify({"error":"No JSON body provided"}), 400
    rows = data if isinstance(data, list) else [data]
    df = pd.DataFrame(rows)
    try:
        df = normalize_df(df)
    except Exception as e:
        return jsonify({"error": str(e)}), 400

    X = df[FEATURES].astype(float).values
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)

    k, sil_score = choose_k_by_silhouette(X_scaled, 2, 8)
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    labels = kmeans.fit_predict(X_scaled)

    results = []
    for i, lab in enumerate(labels):
        row = df.iloc[i].to_dict()
        rec = recommend_from_row(row.get('Annual Income (k$)'), row.get('Spending Score (1-100)'))
        results.append({"input":row, "cluster":int(lab), "recommendation":rec})
    return jsonify({"k": int(k), "silhouette": float(sil_score), "results": results})

if __name__ == "__main__":
    port = int(os.environ.get("PORT", 8080))
    app.run(host="0.0.0.0", port=port)
